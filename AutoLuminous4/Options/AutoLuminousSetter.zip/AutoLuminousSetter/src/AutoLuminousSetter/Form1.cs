﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

using ExpressionCalculator;

using PEPlugin;
using PEPlugin.Pmx;


namespace AutoLuminousSetter
{
    public partial class Form1 : Form
    {

        IPEPluginHost Host; //プラグインホスト
        IPXPmx pmx = null; //PMDデータを保存・画面がアクティブになるたびに更新

        public static bool shown = false;

        public Form1(IPEPluginHost host)
        {
            InitializeComponent();

            this.Host = host;

            this.Width -= listMaterial.Width + 24;

            SetForm(ALSetting.GetNew());

            //自分自身のAssemblyを取得し、バージョンを返す
            System.Reflection.Assembly asm =
                System.Reflection.Assembly.GetExecutingAssembly();
            System.Version ver = asm.GetName().Version;
            this.Text += " " + ver.ToString();


        }



        bool MaterialMode = false;

        private void btnSetMat_Click(object sender, EventArgs e)
        {

            listMaterial.Enabled = !MaterialMode;
            btnSetSelMat.Enabled = !MaterialMode;
            checkAutoLoadMaterialSetting.Enabled = !MaterialMode;


            if (MaterialMode)
            {
                btnSetMat.Text = "材質から適用 >>";
                this.Width -= listMaterial.Width + 24;
                MaterialMode = false;

            }
            else
            {
                btnSetMat.Text = "材質から適用 <<";
                this.Width += listMaterial.Width + 24;
                MaterialMode = true;

                IPXPmx currentpmx = Host.Connector.Pmx.GetCurrentState();
                pmx = currentpmx;

                MaterialRenew();

            }

        }



        bool DecisionSystemCode(float x, float y)
        {
            bool val = (0.199 < x) && (x < 0.201)
                    && (0.699 < y) && (y < 0.701);
            return val;
        }

        private void RefreshModelInfo()
        {
            
            //現在のPMXを取得
            IPXPmx currentpmx = Host.Connector.Pmx.GetCurrentState();
            int count = 0;

            foreach (IPXVertex vtx in currentpmx.Vertex)
            {
                if (DecisionSystemCode(vtx.UVA1.X, vtx.UVA1.Y))
                {
                    count++;
                }

            }

            pmx = currentpmx;

            if (MaterialMode)
            {
                MaterialRenew();
            }

            if (count == 0)
            {
                lblMessage.Text = "このモデルには頂点発光が設定されていません。";
            }
            else
            {
                lblMessage.Text = count.ToString() + "個の頂点に頂点発光が設定されています。";
            }

        }

        void MaterialRenew()
        {
            int i = 0;

            bool MaterialRenewed = false;

            foreach (IPXMaterial mat in pmx.Material)
            {
                string name = mat.Name;

                name = i.ToString() + " : " + name;

                if (ALSetting.ExtractionScript(mat.Memo) != "")
                {
                    name += " *";
                }

                if (listMaterial.Items.Count <= i)
                {
                    listMaterial.Items.Add(name);
                    MaterialRenewed = true;
                }
                else
                {
                    if ((string)listMaterial.Items[i] != name)
                    {
                        listMaterial.Items[i] = name;
                        MaterialRenewed = true;
                    }
                }

                i++;
            }

            if (listMaterial.Items.Count > i)
            {
                for (int j = listMaterial.Items.Count - 1; j >= i; j--)
                {
                    listMaterial.Items.RemoveAt(j);
                    MaterialRenewed = true;
                }
            }

            if (MaterialRenewed)
            {
                listMaterial.SelectedIndex = -1;
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            RefreshModelInfo();
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            RefreshModelInfo();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            shown = false;
        }

        


        void SetForm(ALSetting setting)
        {
            checkEnable.Checked = setting.Enable;
            listColorType.SelectedIndex = setting.ColorType;
            listTexMode.SelectedIndex = setting.TexMode;
            txtTexSub.Text = setting.TexSub;
            txtPopup.Text = setting.Popup;
            txtQ.Text = setting.Q;

            txtR.Text = setting.R;
            txtG.Text = setting.G;
            txtB.Text = setting.B;
            txtPower.Text = setting.Power;

            txtT.Text = setting.Interval;
            txtPhase.Text = setting.Phase;
            checkBRect.Checked = setting.BlinkRect;

            checkMEnable.Checked = setting.MorphEnable;
            txtMName.Text = setting.MName;
            txtMR.Text = setting.MR;
            txtMG.Text = setting.MG;
            txtMB.Text = setting.MB;
            txtMP.Text = setting.MP;

        }

        string ALSFilter(string str)
        {
            str = str.Replace(":", "");
            str = str.Replace("[", "");
            str = str.Replace("]", "");
            str = str.Replace(";", "");
            return str;
        }

        ALSetting GetForm()
        {
            ALSetting setting = new ALSetting();

            setting.Enable = checkEnable.Checked;
            setting.ColorType = listColorType.SelectedIndex;
            setting.TexMode = listTexMode.SelectedIndex;
            setting.TexSub = ALSFilter(txtTexSub.Text);
            setting.Popup = ALSFilter(txtPopup.Text);
            setting.Q = ALSFilter(txtQ.Text);

            setting.R = ALSFilter(txtR.Text);
            setting.G = ALSFilter(txtG.Text);
            setting.B = ALSFilter(txtB.Text);
            setting.Power = ALSFilter(txtPower.Text);

            setting.Interval = ALSFilter(txtT.Text);
            setting.Phase = ALSFilter(txtPhase.Text);
            setting.BlinkRect = checkBRect.Checked;

            setting.MorphEnable = checkMEnable.Checked;
            setting.MName = ALSFilter(txtMName.Text);
            setting.MR = ALSFilter(txtMR.Text);
            setting.MG = ALSFilter(txtMG.Text);
            setting.MB = ALSFilter(txtMB.Text);
            setting.MP = ALSFilter(txtMP.Text);

            return setting;
        }



        private void 現在の設定を保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();

            fd.Filter = "AutoLuminouSetting file|*.als";
            fd.DefaultExt = "als";
            fd.OverwritePrompt = false;

            if (fd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    StreamWriter sw = new StreamWriter(fd.FileName);

                    sw.Write(GetForm().ToString());

                    sw.Close();
                }
                catch
                {
                    MessageBox.Show("ファイル保存に失敗しました", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }

        }


        private void 設定をファイルから開くToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();

            fd.Filter = "AutoLuminouSetting file|*.als";
            fd.DefaultExt = "als";
            
            if (fd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    StreamReader sr = new StreamReader(fd.FileName);

                    SetForm(ALSetting.Parse(sr.ReadToEnd()));

                    sr.Close();
                }
                catch
                {
                    MessageBox.Show("ファイル読み込みに失敗しました", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }



        private void listColorType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listColorType.SelectedIndex == 0)
            {
                lblR.Text = "R:";
                lblG.Text = "G:";
                lblB.Text = "B:";
                lblMR.Text = "R:";
                lblMG.Text = "G:";
                lblMB.Text = "B:";
            }
            else
            {
                lblR.Text = "H:";
                lblG.Text = "S:";
                lblB.Text = "V:";
                lblMR.Text = "H:";
                lblMG.Text = "S:";
                lblMB.Text = "V:";
            }
        }



        private void checkMEnable_CheckedChanged(object sender, EventArgs e)
        {
            if (checkMEnable.Checked)
            {
                if(txtMName.Text == "") txtMName.Text = "ALMorph1";
            }
        }


        private void lbl_Click(object sender, EventArgs e)
        {

            List<GroupBox> gbs = new List<GroupBox>();

            gbs.Add(groupBox1);
            gbs.Add(groupBox2);
            gbs.Add(groupBox3);
            gbs.Add(groupBox5);


            try
            {
                Label lbl = (Label)sender;

                foreach (GroupBox gb in gbs)
                {
                    foreach (Control cnt in gb.Controls)
                    {
                        if (cnt.Name == (string)lbl.Tag)
                        {
                            TextBox txtbox = (TextBox)cnt;

                            txtbox.Focus();
                            txtbox.SelectAll();
                            return;
                        }
                    }

                }
            }
            catch
            {

            }
        }



        void SetMorph(IPXMorph morph)
        {
            if (morph != null)
            {

                //重複削除

                foreach (IPXUVMorphOffset mo in morph.Offsets)
                {
                    mo.Vertex.UVA1.X = 100;
                }

                IPXMorph morph2 = (IPXMorph)morph.Clone();

                morph2.Offsets.Clear();

                foreach (IPXUVMorphOffset mo in morph.Offsets)
                {
                    if (mo.Vertex.UVA1.X > 99)
                    {
                        mo.Vertex.UVA1.X = 0.2f;
                        morph2.Offsets.Add(mo);
                    }
                }

                //上書き

                if (checkMOverride.Checked)
                {
                    foreach (IPXMorph smorph in pmx.Morph)
                    {
                        if (morph2.Name == smorph.Name)
                        {

                            smorph.Kind = MorphKind.UVA2;
                            smorph.Offsets.Clear();

                            foreach (IPXMorphOffset mo in morph2.Offsets)
                            {
                                smorph.Offsets.Add(mo);
                            }

                            return;
                        }

                        
                    }
                }

                //新規追加

                pmx.Morph.Add(morph2);
            }

        }


        IPXMorph SetALSetting(List<IPXVertex> vtxs, ALSetting setting, IPXMaterial mat, IPXMorph morph)
        {

            float dr = 0, dg = 0, db = 0, da = 1;
            float sr = 0, sg = 0, sb = 0, sp = 0;
            float ar = 0, ag = 0, ab = 0;


            if (mat != null)
            {
                dr = mat.Diffuse.R;
                dg = mat.Diffuse.G;
                db = mat.Diffuse.B;
                da = mat.Diffuse.A;

                sr = mat.Specular.R;
                sg = mat.Specular.G;
                sb = mat.Specular.B;
                sp = mat.Power;

                ar = mat.Ambient.R;
                ag = mat.Ambient.G;
                ab = mat.Ambient.B;

            }

            bool IsNumeric = true;

            double TexSub = 0;
            double Popup = 0;
            double R = 0;
            double G = 0;
            double B = 0;
            double Power = 0;
            double Interval = 0;
            double Phase = 0;
            double MR = 0;
            double MG = 0;
            double MB = 0;
            double MP = 0;


            IsNumeric &= double.TryParse(setting.TexSub, out TexSub);
            IsNumeric &= double.TryParse(setting.Popup, out Popup);
            IsNumeric &= double.TryParse(setting.R, out R);
            IsNumeric &= double.TryParse(setting.G, out G);
            IsNumeric &= double.TryParse(setting.B, out B);
            IsNumeric &= double.TryParse(setting.Power, out Power);
            IsNumeric &= double.TryParse(setting.Interval, out Interval);
            IsNumeric &= double.TryParse(setting.Phase, out Phase);

            if (setting.MR != "") IsNumeric &= double.TryParse(setting.MR, out MR);
            if (setting.MG != "") IsNumeric &= double.TryParse(setting.MG, out MG);
            if (setting.MB != "") IsNumeric &= double.TryParse(setting.MB, out MB);
            if (setting.MP != "") IsNumeric &= double.TryParse(setting.MP, out MP);


            ExpCalculator ecalc = new ExpCalculator(StringComparer.InvariantCultureIgnoreCase);

            if (morph == null)
            {
                morph = Host.Builder.Pmx.Morph();
            }

            if (setting.MorphEnable)
            {
                morph.Name = setting.MName;
                morph.Kind = MorphKind.UVA2;
                morph.Panel = 4;

            }


            List<ExpCalculator.Token> la_TexSub = null;
            List<ExpCalculator.Token> la_Popup = null;
            List<ExpCalculator.Token> la_Q = null;
            List<ExpCalculator.Token> la_R = null;
            List<ExpCalculator.Token> la_G = null;
            List<ExpCalculator.Token> la_B = null;
            List<ExpCalculator.Token> la_Power = null;
            List<ExpCalculator.Token> la_Interval = null;
            List<ExpCalculator.Token> la_Phase = null;
            List<ExpCalculator.Token> la_MR = null;
            List<ExpCalculator.Token> la_MG = null;
            List<ExpCalculator.Token> la_MB = null;
            List<ExpCalculator.Token> la_MP = null;

            if (!IsNumeric)
            {
                la_TexSub = ecalc.LexicalAnalyzer(setting.TexSub);
                la_Popup = ecalc.LexicalAnalyzer(setting.Popup);
                la_Q = ecalc.LexicalAnalyzer(setting.Q);
                la_R = ecalc.LexicalAnalyzer(setting.R);
                la_G = ecalc.LexicalAnalyzer(setting.G);
                la_B = ecalc.LexicalAnalyzer(setting.B);
                la_Power = ecalc.LexicalAnalyzer(setting.Power);
                la_Interval = ecalc.LexicalAnalyzer(setting.Interval);
                la_Phase = ecalc.LexicalAnalyzer(setting.Phase);
                la_MR = ecalc.LexicalAnalyzer(setting.MR);
                la_MG = ecalc.LexicalAnalyzer(setting.MG);
                la_MB = ecalc.LexicalAnalyzer(setting.MB);
                la_MP = ecalc.LexicalAnalyzer(setting.MP);

            }

            foreach (IPXVertex vtx in vtxs)
            {

                if (setting.Enable)
                {

                    if (!IsNumeric)
                    {

                        Dictionary<string, double> dparam = new Dictionary<string, double>(StringComparer.InvariantCultureIgnoreCase);
                        Dictionary<string, int> iparam = new Dictionary<string, int>(StringComparer.InvariantCultureIgnoreCase);

                        dparam.Add("DR", dr);
                        dparam.Add("DG", dg);
                        dparam.Add("DB", db);
                        dparam.Add("DA", da);

                        dparam.Add("SR", sr);
                        dparam.Add("SG", sg);
                        dparam.Add("SB", sb);
                        dparam.Add("SP", sp);

                        dparam.Add("AR", ar);
                        dparam.Add("AG", ag);
                        dparam.Add("AB", ab);

                        dparam.Add("X", vtx.Position.X);
                        dparam.Add("Y", vtx.Position.Y);
                        dparam.Add("Z", vtx.Position.Z);

                        dparam.Add("NX", vtx.Normal.X);
                        dparam.Add("NY", vtx.Normal.Y);
                        dparam.Add("NZ", vtx.Normal.Z);

                        dparam.Add("U", vtx.UV.X);
                        dparam.Add("V", vtx.UV.Y);

                        double Q = ecalc.Parse(la_Q, iparam, dparam);

                        dparam.Add("Q", Q);


                        TexSub = ecalc.Parse(la_TexSub, iparam, dparam);
                        Popup = ecalc.Parse(la_Popup, iparam, dparam);
                        R = ecalc.Parse(la_R, iparam, dparam);
                        G = ecalc.Parse(la_G, iparam, dparam);
                        B = ecalc.Parse(la_B, iparam, dparam);
                        Power = ecalc.Parse(la_Power, iparam, dparam);
                        Interval = ecalc.Parse(la_Interval, iparam, dparam);
                        Phase = ecalc.Parse(la_Phase, iparam, dparam);

                        if (setting.MR != "")
                        {
                            dparam.Add("BASE", R);
                            MR = ecalc.Parse(la_MR, iparam, dparam);
                            dparam.Remove("BASE");
                        }
                        if (setting.MG != "")
                        {
                            dparam.Add("BASE", G);
                            MG = ecalc.Parse(la_MG, iparam, dparam);
                            dparam.Remove("BASE");
                        }
                        if (setting.MB != "")
                        {
                            dparam.Add("BASE", B);
                            MB = ecalc.Parse(la_MB, iparam, dparam);
                            dparam.Remove("BASE");
                        }
                        if (setting.MP != "")
                        {
                            dparam.Add("BASE", Power);
                            MP = ecalc.Parse(la_MP, iparam, dparam);
                            dparam.Remove("BASE");
                        }
                    }

                    Interval = Math.Abs(Interval);
                    if (setting.BlinkRect) Interval = -Interval;

                    float Flag = setting.TexMode + setting.ColorType * 10;

                    vtx.UVA1.X = 0.2f;
                    vtx.UVA1.Y = 0.7f;
                    vtx.UVA1.Z = (float)Interval;
                    vtx.UVA1.W = Flag;

                    vtx.UVA2.X = (float)R;
                    vtx.UVA2.Y = (float)G;
                    vtx.UVA2.Z = (float)B;
                    vtx.UVA2.W = (float)Power;

                    vtx.UVA3.X = (float)TexSub;
                    vtx.UVA3.Y = (float)Phase;
                    vtx.UVA3.Z = (float)Popup;
                    vtx.UVA3.W = 0;


                    if (setting.MorphEnable)
                    {
                        IPXUVMorphOffset mofs = Host.Builder.Pmx.UVMorphOffset();

                        mofs.Vertex = vtx;
                        if (setting.MR != "") mofs.Offset.X = (float)(MR - R);
                        if (setting.MG != "") mofs.Offset.Y = (float)(MG - G);
                        if (setting.MB != "") mofs.Offset.Z = (float)(MB - B);
                        if (setting.MP != "") mofs.Offset.W = (float)(MP - Power);


                        morph.Offsets.Add(mofs);
                    }

                }
                else
                {
                    vtx.UVA1 = new PEPlugin.SDX.V4();
                    vtx.UVA2 = new PEPlugin.SDX.V4();
                    vtx.UVA3 = new PEPlugin.SDX.V4();
                    morph = null;
                }

                if (!setting.MorphEnable) morph = null;
            }
            

            return morph;
        }



        void PmxUpdate()
        {

            if (pmx.Header.UVACount < 3) pmx.Header.UVACount = 3;

            Host.Connector.Pmx.Update(pmx);
            Host.Connector.Form.UpdateList(PEPlugin.Pmd.UpdateObject.All);
            Host.Connector.View.PMDView.UpdateModel();
            Host.Connector.View.PMDView.UpdateView();

            RefreshModelInfo();
        }

        private void btnSetSelVtx_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "設定しています...";
            Application.DoEvents();

            List<IPXVertex> vtxs = new List<IPXVertex>();
            int[] ilist = Host.Connector.View.PMDView.GetSelectedVertexIndices();

            if (ilist.Length <= 0)
            {
                lblMessage.Text = "頂点が選択されていません。";
                return;
            }

            foreach (int i in ilist)
            {
                vtxs.Add(pmx.Vertex[i]);
            }

            IPXMorph morph;

            try
            {
                morph = SetALSetting(vtxs, GetForm(), null, null);
            }
            catch
            {
                lblMessage.Text = "不正なパラメータが見つかりました。";
                return;
            }

            SetMorph(morph);

            PmxUpdate();
        }

        private void btnSetSelMat_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "設定しています...";
            Application.DoEvents();

            if (listMaterial.SelectedIndices.Count <= 0)
            {
                lblMessage.Text = "材質が選択されていません。";
                return;
            }


            ALSetting setting = GetForm();
            IPXMorph morph = null;

            try
            {
                foreach (int i in listMaterial.SelectedIndices)
                {

                    IPXMaterial mat = pmx.Material[i];
                    List<IPXVertex> vtxs = new List<IPXVertex>();

                    foreach (IPXFace face in mat.Faces)
                    {
                        vtxs.Add(face.Vertex1);
                        vtxs.Add(face.Vertex2);
                        vtxs.Add(face.Vertex3);
                    }


                    morph = SetALSetting(vtxs, setting, mat, morph);


                    string script = ALSetting.ExtractionScript(mat.Memo);

                    if (script == "")
                    {
                        mat.Memo = mat.Memo + setting.ToString();
                    }
                    else
                    {
                        mat.Memo = mat.Memo.Replace(script, setting.ToString());
                    }
                }
            }
            catch
            {
                lblMessage.Text = "不正なパラメータが見つかりました。";
                return;
            }


            SetMorph(morph);


            PmxUpdate();


        }



        private void listMaterial_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (listMaterial.SelectedIndex >= 0 && checkAutoLoadMaterialSetting.Checked)
            {
                IPXMaterial mat = pmx.Material[listMaterial.SelectedIndex];
                string script = ALSetting.ExtractionScript(mat.Memo);

                if (script != "")
                {
                    try
                    {
                        SetForm(ALSetting.Parse(script));
                    }
                    catch
                    {

                    }
                }

            }

        }


        private void 設定コピーToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.Clear();
            Clipboard.SetText(GetForm().ToString());
        }

        private void 設定ペーストToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                string str = Clipboard.GetText();

                SetForm(ALSetting.Parse(str));
            }
            catch
            {
                lblMessage.Text = "クリップボードに正しいデータがありません。";
            }
        }

        private void 変数一覧ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmHelp1 frmh1 = new frmHelp1();
            frmh1.Show(this);
        }

        private void 関数一覧ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmHelp2 frmh2 = new frmHelp2();
            frmh2.Show(this);
        }

        private void 全頂点に適用ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "設定しています...";
            Application.DoEvents();

            List<IPXVertex> vtxs = new List<IPXVertex>();
            
            if (pmx.Vertex.Count <= 0)
            {
                lblMessage.Text = "頂点がありません。";
                return;
            }

            foreach (IPXVertex vtx in pmx.Vertex)
            {
                vtxs.Add(vtx);
            }

            IPXMorph morph;

            try
            {
                morph = SetALSetting(vtxs, GetForm(), null, null);
            }
            catch
            {
                lblMessage.Text = "不正なパラメータが見つかりました。";
                return;
            }

            SetMorph(morph);

            PmxUpdate();
        }

        private void 画面上の設定をリセットToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetForm(ALSetting.GetNew());

        }

        private void すべての設定を消去ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (IPXMaterial mat in pmx.Material)
            {
                string script = ALSetting.ExtractionScript(mat.Memo);

                if (script != "")
                {
                    mat.Memo = mat.Memo.Replace(script, "");
                }
            }

            PmxUpdate();
        }

        private void すべての追加UVを消去ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (IPXVertex vtx in pmx.Vertex)
            {
                if (DecisionSystemCode(vtx.UVA1.X, vtx.UVA1.Y))
                {
                    vtx.UVA1 = new PEPlugin.SDX.V4();
                    vtx.UVA2 = new PEPlugin.SDX.V4();
                    vtx.UVA3 = new PEPlugin.SDX.V4();
                }
                
            }

            PmxUpdate();
        }




    }
}
