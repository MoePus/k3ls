﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Windows.Forms;

namespace AutoLuminousSetter
{
    struct ALSetting
    {
        public bool Enable;
        public int ColorType;
        public int TexMode;
        public string TexSub;
        public string Popup;
        public string Q;

        public string R;
        public string G;
        public string B;
        public string Power;

        public string Interval;
        public string Phase;
        public bool BlinkRect;

        public bool MorphEnable;
        public string MName;
        public string MR;
        public string MG;
        public string MB;
        public string MP;

        public void Reset()
        {
            Enable = true;
            ColorType = 0;
            TexMode = 0;
            TexSub = "0";
            Popup = "0";
            Q = "0";

            R = "0";
            G = "0";
            B = "0";
            Power = "0";

            Interval = "0";
            Phase = "0";
            BlinkRect = false;

            MorphEnable = false;
            MName = "";
            MR = "";
            MG = "";
            MB = "";
            MP = "";

        }

        public static ALSetting GetNew()
        {
            ALSetting setting = new ALSetting();
            setting.Reset();
            return setting;
        }

        public const string Header = "[ALS=";

        override public string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(Header);

            sb.Append("EN:"); sb.Append(Enable); sb.Append(";");
            sb.Append("CT:"); sb.Append(ColorType); sb.Append(";");
            sb.Append("TM:"); sb.Append(TexMode); sb.Append(";");
            sb.Append("TS:"); sb.Append(TexSub); sb.Append(";");
            sb.Append("PU:"); sb.Append(Popup); sb.Append(";");
            sb.Append("Q:"); sb.Append(Q); sb.Append(";");

            sb.Append("CR:"); sb.Append(R); sb.Append(";");
            sb.Append("CG:"); sb.Append(G); sb.Append(";");
            sb.Append("CB:"); sb.Append(B); sb.Append(";");
            sb.Append("CP:"); sb.Append(Power); sb.Append(";");

            sb.Append("BI:"); sb.Append(Interval); sb.Append(";");
            sb.Append("BP:"); sb.Append(Phase); sb.Append(";");
            sb.Append("BR:"); sb.Append(BlinkRect); sb.Append(";");

            sb.Append("ME:"); sb.Append(MorphEnable); sb.Append(";");
            if (MName != "") { sb.Append("MN:"); sb.Append(MName); sb.Append(";"); }

            if (MR != "") { sb.Append("MR:"); sb.Append(MR); sb.Append(";"); }
            if (MG != "") { sb.Append("MG:"); sb.Append(MG); sb.Append(";"); }
            if (MB != "") { sb.Append("MB:"); sb.Append(MB); sb.Append(";"); }
            if (MP != "") { sb.Append("MP:"); sb.Append(MP); sb.Append(";"); }

            sb.Append("]");

            return sb.ToString();
        }

        const string ErrMsg_InvSyntax = "Invalid Syntax.";

        public static bool CheckHead(string script)
        {
            return script.StartsWith(Header);
        }

        public static ALSetting Parse(string script)
        {
            ALSetting als = new ALSetting();

            if (!CheckHead(script))
            {
                throw new System.Exception(ErrMsg_InvSyntax);
            }

            if (!script.EndsWith("]"))
            {
                throw new System.Exception(ErrMsg_InvSyntax);
            }

            als.Reset();

            script = script.Substring(Header.Length);
            script = script.Substring(0, script.Length - 1);

            string[] elements = script.Split(';');

            foreach (string element in elements)
            {
                if (element != "")
                {
                    int i = element.IndexOf(':');

                    if (i <= 0) throw new System.Exception(ErrMsg_InvSyntax);

                    string head = element.Substring(0, i);
                    string valstr = "";

                    if (element.Length > i + 1) valstr = element.Substring(i + 1);

                    switch (head)
                    {
                        case "EN":
                            als.Enable = bool.Parse(valstr);
                            break;
                        case "CT":
                            als.ColorType = int.Parse(valstr);
                            break;
                        case "TM":
                            als.TexMode = int.Parse(valstr);
                            break;
                        case "TS":
                            als.TexSub = valstr;
                            break;
                        case "PU":
                            als.Popup = valstr;
                            break;
                        case "Q":
                            als.Q = valstr;
                            break;

                        case "CR":
                            als.R = valstr;
                            break;
                        case "CG":
                            als.G = valstr;
                            break;
                        case "CB":
                            als.B = valstr;
                            break;
                        case "CP":
                            als.Power = valstr;
                            break;

                        case "BI":
                            als.Interval = valstr;
                            break;
                        case "BP":
                            als.Phase = valstr;
                            break;
                        case "BR":
                            als.BlinkRect = bool.Parse(valstr);
                            break;

                        case "ME":
                            als.MorphEnable = bool.Parse(valstr);
                            break;
                        case "MN":
                            als.MName = valstr;
                            break;
                        case "MR":
                            als.MR = valstr;
                            break;
                        case "MG":
                            als.MG = valstr;
                            break;
                        case "MB":
                            als.MB = valstr;
                            break;
                        case "MP":
                            als.MP = valstr;
                            break;

                    }

                }
            }

            return als;
        }



        public static string ExtractionScript(string script)
        {
            string strret = "";

            int i;
            int j = script.IndexOf(Header);

            if (j >= 0)
            {
                for (i = j; i < script.Length; i++)
                {
                    if (script[i] == ']')
                    {
                        strret = script.Substring(j, i - j + 1);
                    }
                }
            }

            return strret;
        }


    }


}
